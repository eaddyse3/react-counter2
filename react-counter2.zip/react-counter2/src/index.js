import React from 'react';
import { render } from 'react-dom';
import { createStore } from 'redux';
import { connect } from 'react-redux';
import { Provider } from 'react-redux';

const initialState = {
  count: 0
}

const reducer = (state = initialState, action) => {
  switch(action.type) {
    case 'increment':
  return {...state, count: state.count + 1};
  case 'decrement':
  return {    ...state, count: state.count - 1};
  case 'reset':
  return {...state, couint: state.count = 0}
  default:
  return state;
}
}

const store = createStore(reducer);

const mapStateToProps = (state) => {
  return {
    count: state.count
  }
}

const mapDispatchToProps = (dispatch) => {
  return{
    onIncrement: () => store.dispatch({type: 'increment'}),
    onDecrement: () => store.dispatch({type: 'decrement'}),
    onReset: () => store.dispatch({type: 'reset'})
    
  }
}

const Counter = ({ value, onIncrement, onDecrement, onReset }) => (
<div>
  <h1>{value}</h1>
  <button onClick= {onIncrement}>+</button>
  <button onClick= {onReset}>Reset</button>
  <button onClick= {onDecrement}>-</button>
  </div>  
) 
  

const ConnectedCounter = connect(mapStateToProps, mapDispatchToProps)(Counter);



render(
<Provider store={store}>
  <ConnectedCounter />
  </Provider>,
   document.getElementById('root'));